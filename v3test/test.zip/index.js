const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const client = new DynamoDBClient({});
const {
    GetItemCommand
} = require("@aws-sdk/client-dynamodb");
const { marshall , unmarshall} = require("@aws-sdk/util-dynamodb");

const getPost = async (event) => {
    const response  = { statusCode : 200};

    try {
        const params = {
            TableName : 't_discoteca_eventos',
            Key: marshall({ discoteca_nomnre: "disco"})
        };
        const { Item } = await client.send(new GetItemCommand(params));
        console.log({ Item });
        response.body  = JSON.stringify({
            message : "succesfully retrieved post",
            data: (Item) ? unmarshall(Item) : {},
            rawData: Item, 
        });
    } catch (e) {
        console.error(e);
        response.statusCode = 500;
        response.body = JSON.stringify({
            message: "Failed to get post",
            errorMsg : e.message,
            errorStack: e.stack
        });
    }
    return response;
}